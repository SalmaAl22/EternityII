Final Project made by 
Ryan Morin 40155922
Salma Alalwani 40133627

This file contains the text file with the peices for the 16x16 ETERNITY II puzzle.
It will automatically take them from the file.

To run the code:

Open the java file and execute it.